package com.example.jarvis

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        tts = TextToSpeech(this, this)
        findViewById<Button>(R.id.listen).setOnClickListener { listen() }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
            speak("नमस्ते, मैं जार्विस हूँ। बोलिए।")
        }
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("इस फोन पर speech recognition उपलब्ध नहीं है।")
            return
        }
        status.text = "सुन रहा हूँ..."
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                handleCommand(phrase.lowercase(Locale.getDefault()))
            }
            override fun onError(error: Int) { status.text = "फिर से बोलिए" }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS सुन रहा है")
        }
        recognizer?.startListening(intent)
    }

    private fun handleCommand(command: String) {
        status.text = "आपने कहा: $command"
        when {
            command.contains("यूट्यूब") || command.contains("youtube") -> {
                speak("YouTube खोल रहा हूँ।")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
            }
            command.contains("गूगल") || command.contains("google") -> {
                speak("Google खोल रहा हूँ।")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
            }
            command.contains("सेटिंग") || command.contains("settings") -> {
                speak("सेटिंग खोल रहा हूँ।")
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            }
            command.contains("हैलो") || command.contains("hello") || command.contains("जार्विस") -> {
                speak("हाँ, मैं सुन रहा हूँ।")
            }
            else -> speak("मैंने सुना: $command. इस command को अगले version में जोड़ सकते हैं।")
        }
    }

    private fun speak(text: String) { tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }
    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
