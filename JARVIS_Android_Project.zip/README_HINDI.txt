JARVIS Android Project - Version 1
यह Android Studio project है, सीधे install होने वाला APK नहीं।
APK बनाने के लिए कंप्यूटर पर Android Studio खोलें, इस folder को खोलें और Build > Build APK(s) चुनें।
इस शुरुआती version में बटन दबाकर Hindi voice input, बोलकर जवाब, और Google/YouTube/Settings खोलने की basic commands हैं।
यह हमेशा background में wake word सुनने, lock-screen पर पूर्ण नियंत्रण, या WhatsApp/SMS स्वतः भेजने की सुविधा नहीं देता।
